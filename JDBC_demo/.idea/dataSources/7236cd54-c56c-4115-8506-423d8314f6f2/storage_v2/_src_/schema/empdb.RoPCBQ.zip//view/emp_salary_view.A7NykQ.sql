create definer = root@`%` view emp_salary_view as
select `empdb`.`emp`.`empno`                                      AS `employee_no`,
       `empdb`.`emp`.`ename`                                      AS `employee_name`,
       `empdb`.`emp`.`salary`                                     AS `employee_salary`,
       `empdb`.`emp`.`comm`                                       AS `employee_comm`,
       `empdb`.`emp`.`deptno`                                     AS `department_no`,
       (`empdb`.`emp`.`salary` + ifnull(`empdb`.`emp`.`comm`, 0)) AS `total_salary`
from `empdb`.`emp`
where (`empdb`.`emp`.`deptno` = 30);

