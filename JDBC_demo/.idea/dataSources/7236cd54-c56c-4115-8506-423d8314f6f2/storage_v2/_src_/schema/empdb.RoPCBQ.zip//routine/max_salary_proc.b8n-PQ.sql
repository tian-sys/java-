create
  definer = root@`%` procedure max_salary_proc(OUT v1 decimal(8, 2))
begin
	 select max(salary) into v1 from emp;
end;

