create definer = root@`%` view emp_view1 as
select `empdb`.`emp`.`empno`    AS `empno`,
       `empdb`.`emp`.`ename`    AS `ename`,
       `empdb`.`emp`.`job`      AS `job`,
       `empdb`.`emp`.`mgr`      AS `mgr`,
       `empdb`.`emp`.`hiredate` AS `hiredate`,
       `empdb`.`emp`.`salary`   AS `salary`,
       `empdb`.`emp`.`comm`     AS `comm`,
       `empdb`.`emp`.`deptno`   AS `deptno`
from `empdb`.`emp`
where (`empdb`.`emp`.`deptno` = 30);

