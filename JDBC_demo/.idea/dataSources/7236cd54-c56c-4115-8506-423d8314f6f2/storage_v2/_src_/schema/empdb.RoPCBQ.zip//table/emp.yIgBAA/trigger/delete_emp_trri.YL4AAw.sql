create definer = root@`%` trigger delete_emp_trri
  after DELETE
  on emp
  for each row
begin
	insert into emp_temp values(old.empno,old.ename,old.job,old.mgr,old.hiredate,old.salary,old.comm,old.deptno);
end;

