create
  definer = root@`%` procedure ename_proc()
begin
	select ename from emp;
end;

