create
  definer = root@`%` procedure emp_avg_salary_proc()
begin
	select floor(avg(salary)) from emp;
end;

