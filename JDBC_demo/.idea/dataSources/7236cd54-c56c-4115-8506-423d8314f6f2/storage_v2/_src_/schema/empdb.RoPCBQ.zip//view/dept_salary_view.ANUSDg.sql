create definer = root@`%` view dept_salary_view as
select `e`.`deptno` AS `dno`, `d`.`dname` AS `dname`, avg(`e`.`salary`) AS `avg_salary`
from (`empdb`.`emp` `e`
       join `empdb`.`dept` `d` on ((`e`.`deptno` = `d`.`deptno`)))
group by `e`.`deptno`;

